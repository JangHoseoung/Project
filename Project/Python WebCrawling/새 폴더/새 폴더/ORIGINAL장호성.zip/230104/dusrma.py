from bs4 import BeautifulSoup
import requests

def dusrma(insu):
    url  = f'https://www.nps.or.kr/jsppage/app/etc/simpleExpect.jsp?yyyy=2022&status=cal&max=471600&min=29700&insu={insu}&inquiry=%BF%B9%BB%F3%BF%AC%B1%DD%BE%D7+%C1%B6%C8%B8%C7%CF%B1%E2'
    req = requests.get(url)
    req.encoding = "utf-8"
    html = BeautifulSoup(req.content,"html.parser")

    years10 = html.find('dt', class_='th1_1 th1').find_next_sibling().find('span').text
    years15 = html.find('dt', class_='th1_2 th1').find_next_sibling().find('span').text
    years20 = html.find('dt', class_='th1_3 th1').find_next_sibling().find('span').text
    years25 = html.find('dt', class_='th1_4 th1').find_next_sibling().find('span').text
    years30 = html.find('dt', class_='th1_5 th1').find_next_sibling().find('span').text
    years35 = html.find('dt', class_='th1_6 th1').find_next_sibling().find('span').text
    years40 = html.find('dt', class_='th1_7 th1').find_next_sibling().find('span').text

    a = f"노령연금"
    print(a)
    b = [years10, years15, years20, years25, years30, years35, years40]
    return b
